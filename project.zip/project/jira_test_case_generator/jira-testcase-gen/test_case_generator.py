import openai
import os
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

def load_prompt_template():
    with open("prompts/test_case_prompt.txt", "r") as f:
        return f.read()

def generate_test_cases(ticket_description: str):
    prompt_template = load_prompt_template()
    full_prompt = prompt_template.replace("{{TICKET_DESCRIPTION}}", ticket_description)

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a senior QA engineer."},
            {"role": "user", "content": full_prompt}
        ],
        temperature=0.4
    )

    return response["choices"][0]["message"]["content"]