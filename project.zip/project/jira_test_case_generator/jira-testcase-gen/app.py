from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from test_case_generator import generate_test_cases

app = FastAPI()

class TicketRequest(BaseModel):
    ticket_description: str

@app.post("/generate-test-cases/")
def create_test_cases(request: TicketRequest):
    try:
        cases = generate_test_cases(request.ticket_description)
        return {"test_cases": cases}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))