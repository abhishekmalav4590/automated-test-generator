async function generateTestCases() {
  const ticketText = document.getElementById("ticketInput").value.trim();
  const output = document.getElementById("testCases");
  const loading = document.getElementById("loading");
  
  // Clear previous output
  output.innerHTML = '';
  document.getElementById("output").style.display = "none";

  if (ticketText === "") {
    output.innerText = "Please enter a valid Jira ticket description!";
    document.getElementById("output").style.display = "block";
    return;
  }

  // Show loading spinner
  loading.style.display = "flex";

  try {
    const response = await fetch("http://localhost:8000/generate-test-cases/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ ticket_description: ticketText })
    });

    if (response.ok) {
      const data = await response.json();
      output.innerText = data.test_cases;
    } else {
      output.innerText = "❌ Error generating test cases. Please try again.";
    }
  } catch (error) {
    output.innerText = "❌ Network error, please try again later.";
  }

  // Hide loading spinner and show results
  loading.style.display = "none";
  document.getElementById("output").style.display = "block";
}
